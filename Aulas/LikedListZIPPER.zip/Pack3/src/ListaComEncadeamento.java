public class ListaComEncadeamento {
    private NoLista first;
    private NoLista last;
    private int counter;

    public ListaComEncadeamento(){
        this.counter=0;
        this.first=null;
        this.last=null;
    }
    public void add(Integer element){
        NoLista objeto = new NoLista(element,null);
        if(first==null){
            this.first=objeto;
        }else{
            this.last.setNext(objeto); //
        }
        this.last=objeto;
        counter++;

    }
    public void add(int index, Integer element){
        if(index<0||index>counter){
            throw new IndexOutOfBoundsException("Index "+index+", Size: "+counter);
        }
        NoLista novo = new NoLista(element,null);
        if(index==0){
            novo.setNext(first);
            first=novo;
        }else if(index==counter){
            last.setNext(novo);
            last=novo;
        }else{
            NoLista aux = first;
            for (int i = 0; i < index-1; i++) {
                aux= aux.getnext();
            }
            novo.setNext(aux.getnext());
            aux.setNext(novo);
        }
        counter++;
    }
    public Integer remove(int index){

    }
    public boolean removeFirst(Integer element){

    }
    public Integer get(int index){
        if(index <0 || index>= counter){
            throw new IndexOutOfBoundsException("Index "+index+", Size: "+counter);
        }
        NoLista aux = first;
        for (int i = 0; i < index; i++) {
            aux= aux.getNext();
        }
        return aux.getinfo();
    }
    public void clear(){
        first=null;
        last=null;
        counter=0;
    }
    public Integer set(int index, Integer element){
        if(index <0 || index>= counter){
            throw new IndexOutOfBoundsException("Index "+index+", Size: "+counter);
        }
        NoLista aux = first;
        for (int i = 0; i < index; i++) {
            aux= aux.getNext();
        }
        Integer toReturn= aux.getinfo();
        aux.setInfo(element);
        return toReturn;
    }
    public int size(){
        return counter;
    }
    public boolean isEmpty(){
        return(counter==0);
    }
    public boolean contains(Integer element){
        return (indexOf(element)!=-1);
    }
    public int indexOf(Integer element){

    }
    public int lastIndexOf(Integer element){

    }
    public Integer[] toArray(){

    }
    public String toString(){
        String myarray1="[ ";
        
    }

}
