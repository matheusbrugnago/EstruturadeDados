import java.util.LinkedList;

public class TesteDaListaComEncadeamento {
    LinkedList numero2= new LinkedList();
    ListaComEncadeamento numero= new ListaComEncadeamento();

    public static void main(String[] args) {
        numeros.add(903);
        numeros.add(105);
        numeros.add(45);
        numeros.add(1);
        numeros.add(890);
        numeros.add(1902);
        System.out.println(numeros);
        System.out.println("Existe o 66? "+numeros.contains(66));
        System.out.println("Existe o 45? "+numeros.contains(66));
        numeros.add(0,,777);
        System.out.println(numeros);
        numeros.add(7,1);
        System.out.println("Qual o tamanho?"+numeros.size());
        System.out.println("Removeu elemento no índice 0: "+numeros.remove(0));
        System.out.println(numeros);
        System.out.println("Removeu elemento no índice 4:"+numeros.remove(4));
        System.out.println(numeros);
        if (!numeros.isEmpty()){
            for(int i=0;i<numeros.size();i++){
                System.out.println(numeros.get(i)+" ");
            }
        }
    }
}
